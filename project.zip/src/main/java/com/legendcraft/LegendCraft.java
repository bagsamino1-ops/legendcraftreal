package com.legendcraft;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.tags.BlockTags;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.client.gui.screens.MenuScreens;

@Mod(LegendCraft.MODID)
public class LegendCraft {
    public static final String MODID = "legendcraft";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);

    public static final RegistryObject<Block> MYTHIC_TABLE = BLOCKS.register("mythic_table",
            () -> new MythicTableBlock(BlockBehaviour.Properties.of().strength(5f, 1200f)
                    .requiresCorrectToolForDrops().lightLevel(s -> 12).sound(SoundType.AMETHYST)));
    public static final RegistryObject<Item> MYTHIC_TABLE_ITEM = ITEMS.register("mythic_table",
            () -> new BlockItem(MYTHIC_TABLE.get(), new Item.Properties().rarity(Rarity.EPIC)));

    public static final Tier MYTHIC_TIER = new ForgeTier(5, 4000, 14f, 8f, 30,
            BlockTags.NEEDS_DIAMOND_TOOL, () -> Ingredient.of(Items.NETHERITE_INGOT));
    public static final RegistryObject<Item> MYTHIC_BLADE = ITEMS.register("mythic_blade",
            () -> new SwordItem(MYTHIC_TIER, 10, -2.0f, new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<MenuType<MythicTableMenu>> MYTHIC_MENU = MENUS.register("mythic_table",
            () -> IForgeMenuType.create((id, inv, buf) -> new MythicTableMenu(id, inv, net.minecraft.world.inventory.ContainerLevelAccess.NULL)));

    public LegendCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        MENUS.register(bus);
        bus.addListener(this::tab);
        bus.addListener(this::client);
    }

    private void tab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == net.minecraft.world.item.CreativeModeTabs.COMBAT) e.accept(MYTHIC_BLADE);
        if (e.getTabKey() == net.minecraft.world.item.CreativeModeTabs.FUNCTIONAL_BLOCKS) e.accept(MYTHIC_TABLE_ITEM);
    }

    private void client(FMLClientSetupEvent e) {
        e.enqueueWork(() -> MenuScreens.register(MYTHIC_MENU.get(), MythicTableScreen::new));
    }
}
