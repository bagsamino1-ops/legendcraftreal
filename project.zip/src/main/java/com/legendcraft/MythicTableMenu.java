package com.legendcraft;

import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;

public class MythicTableMenu extends AbstractContainerMenu {
    public static final int INPUTS = 15;          // غيّر الرقم لتغيير عدد الخانات الدائرية
    public static final int CX = 88, CY = 62, RADIUS = 46;

    private final SimpleContainer input = new SimpleContainer(INPUTS);
    private final ResultContainer result = new ResultContainer();
    private final ContainerLevelAccess access;

    public MythicTableMenu(int id, Inventory inv, ContainerLevelAccess access) {
        super(LegendCraft.MYTHIC_MENU.get(), id);
        this.access = access;

        // خانة النتيجة (index 0) في المركز
        addSlot(new Slot(result, 0, CX - 8, CY - 8) {
            @Override public boolean mayPlace(ItemStack s) { return false; }
            @Override public void onTake(Player p, ItemStack s) {
                for (int i = 0; i < INPUTS; i++) if (!input.getItem(i).isEmpty()) input.removeItem(i, 1);
                slotsChanged(input);
            }
        });
        // خانات الإدخال على شكل دائرة (index 1..INPUTS)
        for (int i = 0; i < INPUTS; i++) {
            double a = -Math.PI / 2 + 2 * Math.PI * i / INPUTS;
            int x = (int) Math.round(CX + RADIUS * Math.cos(a)) - 8;
            int y = (int) Math.round(CY + RADIUS * Math.sin(a)) - 8;
            addSlot(new Slot(input, i, x, y));
        }
        // حقيبة اللاعب
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 140 + r * 18));
        for (int c = 0; c < 9; c++) addSlot(new Slot(inv, c, 8 + c * 18, 198));

        input.addListener(this::slotsChanged);
    }

    @Override
    public void slotsChanged(Container c) {
        result.setItem(0, MythicRecipes.find(input));
        super.slotsChanged(c);
    }

    @Override
    public void removed(Player p) {
        super.removed(p);
        access.execute((l, pos) -> clearContainer(p, input));
    }

    @Override
    public boolean stillValid(Player p) {
        return stillValid(access, p, LegendCraft.MYTHIC_TABLE.get());
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        ItemStack copy = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        int invStart = INPUTS + 1, invEnd = slots.size();
        if (slot != null && slot.hasItem()) {
            ItemStack s = slot.getItem();
            copy = s.copy();
            if (index == 0) {
                if (!moveItemStackTo(s, invStart, invEnd, true)) return ItemStack.EMPTY;
            } else if (index < invStart) {
                if (!moveItemStackTo(s, invStart, invEnd, false)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(s, 1, invStart, false)) {
                return ItemStack.EMPTY;
            }
            if (s.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
            if (s.getCount() == copy.getCount()) return ItemStack.EMPTY;
            slot.onTake(p, s);
        }
        return copy;
    }
}
