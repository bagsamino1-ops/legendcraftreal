package com.legendcraft;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class MythicTableScreen extends AbstractContainerScreen<MythicTableMenu> {
    public MythicTableScreen(MythicTableMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 222;
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos;
        g.fill(x - 2, y - 2, x + imageWidth + 2, y + imageHeight + 2, 0xFFD4AF37); // إطار ذهبي
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF1B1030);                  // خلفية بنفسجية داكنة
        // حلقة زخرفية حول الدائرة
        int cx = x + MythicTableMenu.CX, cy = y + MythicTableMenu.CY, r = MythicTableMenu.RADIUS;
        for (int a = 0; a < 360; a += 3) {
            int px = cx + (int) Math.round(r * Math.cos(Math.toRadians(a)));
            int py = cy + (int) Math.round(r * Math.sin(Math.toRadians(a)));
            g.fill(px, py, px + 1, py + 1, 0xFF8A4BFF);
        }
        for (Slot s : menu.slots) {
            int sx = x + s.x, sy = y + s.y;
            boolean res = s.index == 0;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, res ? 0xFFFFD700 : 0xFF8A4BFF);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF0E0820);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) { }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        renderTooltip(g, mx, my);
    }
}
