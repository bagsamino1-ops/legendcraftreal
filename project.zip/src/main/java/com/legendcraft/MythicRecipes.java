package com.legendcraft;

import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.*;
import java.util.function.Supplier;

/** وصفات الطاولات: عدد الخانات المستخدمة لكل مادة (بغض النظر عن مكانها). */
public class MythicRecipes {
    public record Recipe(Map<Item, Integer> in, Supplier<ItemStack> out) {}

    public static final List<Recipe> TIER1 = new ArrayList<>();

    static {
        TIER1.add(new Recipe(Map.of(
                Items.DIAMOND_BLOCK, 4,
                Items.NETHERITE_INGOT, 4,
                Items.NETHER_STAR, 1,
                Items.OBSIDIAN, 6),
                () -> new ItemStack(LegendCraft.MYTHIC_BLADE.get())));
        // أضف وصفات جديدة هنا
    }

    public static ItemStack find(Container c) {
        Map<Item, Integer> have = new HashMap<>();
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack s = c.getItem(i);
            if (!s.isEmpty()) have.merge(s.getItem(), 1, Integer::sum);
        }
        if (have.isEmpty()) return ItemStack.EMPTY;
        for (Recipe r : TIER1) if (r.in().equals(have)) return r.out().get();
        return ItemStack.EMPTY;
    }
}
